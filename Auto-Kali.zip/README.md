# \# Auto-Kali: Entorno BSPWM para Kali Linux  

# 

# \## Instalación Automatizada  

# primero actualice su kali con `sudo apt update` y luego   `sudo apt upgrade -y` luego pegue este script:

# 

# ```bash  

# git clone https://github.com/Rick5001/Auto-Kali.git  

# cd Auto-Kali  

# chmod +x install.sh  

# ./install.sh

# ```

# 

# Esto realizara la configuracion de forma automatica

# 

# \### Referencias

# Mr. `S4vitar`

# 

# Mr. `xJackSx`

# 

